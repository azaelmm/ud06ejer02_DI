namespace ud06ejer2.ViewModels;

using System.Collections.ObjectModel;
using ud06ejer2.Models;
using Microsoft.Maui.Controls;
using System.Windows.Input;
using System.ComponentModel;


[QueryProperty(nameof(Items), "pItems")]
public class AddItemNewWindowViewModel : INotifyPropertyChanged
{
    public ObservableCollection<TodoItem> Items { get; set; } = new ObservableCollection<TodoItem>();
    public string NewItemName { get; set; } = string.Empty;
    public bool IsCompleted { get; set; } = false;
    public ICommand AddItemCommand { get; }
    public ICommand CancelCommand { get; }

    public AddItemNewWindowViewModel()
    {
        AddItemCommand = new Command(async () =>
        {
            if (Items != null)
            {
                Items.Add(new TodoItem { Name = NewItemName, IsCompleted = IsCompleted });
                await Shell.Current.GoToAsync("..");
            }
        });

        CancelCommand = new Command(async () =>
        {
            await Shell.Current.GoToAsync("..");
        });
    }

    public event PropertyChangedEventHandler PropertyChanged;
}

