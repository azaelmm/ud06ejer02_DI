using System.Collections.ObjectModel;

namespace ud06ejer2.ViewModels;

using System.Collections.ObjectModel;
using System.Threading.Tasks;
using ud06ejer2.Models;
using Microsoft.Maui.Controls;
using System.Windows.Input;
using System.ComponentModel;

public class MainPageViewModel : INotifyPropertyChanged
{
    public ObservableCollection<TodoItem> Items { get; set; }
    public ICommand AddItemCommandNewWindow { get; }
    public ICommand DeleteItemCommand { get; }

    public MainPageViewModel()
    {
        Items = new ObservableCollection<TodoItem>
        {
            new TodoItem { Name = "Aprende .NET MAUI con Azael", IsCompleted = false },
            new TodoItem { Name = "Dise�ar una aplicacion con .NET MAUI con Azael", IsCompleted = true }
        };

        AddItemCommandNewWindow = new Command(async () =>
        {
            var navigationParameter = new Dictionary<string, object>
            {
                { "pItems", Items }
            };
            await Shell.Current.GoToAsync("AddItemNewWindow", navigationParameter);
        });

        DeleteItemCommand = new Command<TodoItem>(item =>
        {
            Items.Remove(item);
        });
    }

    public event PropertyChangedEventHandler PropertyChanged;
}

