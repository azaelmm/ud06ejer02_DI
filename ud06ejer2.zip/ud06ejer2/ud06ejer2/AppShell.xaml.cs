﻿using ud06ejer2.View;

namespace ud06ejer2
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute("AddItemNewWindow", typeof(AddItemNewWindow));
        }
    }
}
