namespace ud06ejer2.Models;

public class TodoItem
{
    public string Name { get; set; }
    public bool IsCompleted { get; set; }
}
