using Microsoft.Maui.Controls;

namespace ud06ejer2.View;

public partial class AddItemNewWindow : ContentPage
{
    public AddItemNewWindow()
    {
        InitializeComponent();
    }
}
